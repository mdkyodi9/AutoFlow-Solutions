/**
 * Main application component with routing configuration
 * Handles navigation between different pages of the RPA service website
 */
import { HashRouter, Route, Routes } from 'react-router'
import Layout from './components/Layout'
import HomePage from './pages/Home'
import ServicesPage from './pages/Services'
import IndustriesPage from './pages/Industries'
import AboutPage from './pages/About'
import ContactPage from './pages/Contact'

export default function App() {
  return (
    <HashRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/services" element={<ServicesPage />} />
          <Route path="/industries" element={<IndustriesPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
        </Routes>
      </Layout>
    </HashRouter>
  )
}
