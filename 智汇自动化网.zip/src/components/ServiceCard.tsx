/**
 * Service card component for displaying RPA services
 * Features icon, title, description, and optional features list
 */
import { ReactNode } from 'react'
import { LucideIcon } from 'lucide-react'

interface ServiceCardProps {
  icon: LucideIcon
  title: string
  description: string
  features?: string[]
  className?: string
}

export default function ServiceCard({ 
  icon: Icon, 
  title, 
  description, 
  features, 
  className = '' 
}: ServiceCardProps) {
  return (
    <div className={`bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow ${className}`}>
      <div className="flex items-center mb-4">
        <div className="bg-blue-100 rounded-lg p-3 mr-4">
          <Icon className="h-6 w-6 text-blue-600" />
        </div>
        <h3 className="text-xl font-semibold text-gray-900">{title}</h3>
      </div>
      <p className="text-gray-600 mb-4">{description}</p>
      {features && (
        <ul className="space-y-2">
          {features.map((feature, index) => (
            <li key={index} className="flex items-center text-sm text-gray-700">
              <div className="w-1.5 h-1.5 bg-blue-600 rounded-full mr-2"></div>
              {feature}
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
