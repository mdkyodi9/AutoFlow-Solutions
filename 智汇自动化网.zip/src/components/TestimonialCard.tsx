/**
 * Testimonial card component for displaying client feedback
 * Features client photo, name, company, and testimonial text
 */
interface TestimonialCardProps {
  name: string
  company: string
  role: string
  testimonial: string
  avatar: string
}

export default function TestimonialCard({ 
  name, 
  company, 
  role, 
  testimonial, 
  avatar 
}: TestimonialCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center mb-4">
        <img 
          src={avatar} 
          alt={name}
          className="w-12 h-12 rounded-full object-cover mr-4"
        />
        <div>
          <h4 className="font-semibold text-gray-900">{name}</h4>
          <p className="text-sm text-gray-600">{role}</p>
          <p className="text-sm text-blue-600 font-medium">{company}</p>
        </div>
      </div>
      <blockquote className="text-gray-700 italic">
        "{testimonial}"
      </blockquote>
    </div>
  )
}
