/**
 * Services page detailing comprehensive RPA solutions and customization options
 * Showcases different service categories with emphasis on personalization
 */
import { Link } from 'react-router'
import { 
  Search, 
  Code, 
  Rocket, 
  LifeBuoy, 
  TrendingUp,
  ArrowRight,
  Clock,
  DollarSign,
  Target,
  Users
} from 'lucide-react'
import Section from '../components/Section'
import ServiceCard from '../components/ServiceCard'

export default function Services() {
  const mainServices = [
    {
      icon: Search,
      title: 'Process Assessment & Discovery',
      description: 'Comprehensive analysis of your current processes to identify optimal automation opportunities.',
      features: [
        'Current state process mapping',
        'Automation feasibility analysis',
        'ROI calculation and business case',
        'Risk assessment and mitigation planning',
        'Priority matrix development'
      ],
      timeline: '2-4 weeks',
      investment: 'Starting at $5,000'
    },
    {
      icon: Code,
      title: 'Custom RPA Development',
      description: 'Tailored automation solutions built specifically for your unique business requirements.',
      features: [
        'Custom bot development',
        'Multi-system integration',
        'Exception handling logic',
        'Security compliance implementation',
        'Scalable architecture design'
      ],
      timeline: '4-12 weeks',
      investment: 'Starting at $15,000'
    },
    {
      icon: Rocket,
      title: 'Implementation & Deployment',
      description: 'Complete deployment support with testing, training, and go-live assistance.',
      features: [
        'Production environment setup',
        'Comprehensive testing protocols',
        'User training and documentation',
        'Go-live support and monitoring',
        'Performance optimization'
      ],
      timeline: '2-6 weeks',
      investment: 'Starting at $8,000'
    },
    {
      icon: LifeBuoy,
      title: 'Ongoing Support & Maintenance',
      description: 'Continuous monitoring, maintenance, and optimization of your RPA solutions.',
      features: [
        '24/7 monitoring and support',
        'Regular performance reviews',
        'Bot updates and enhancements',
        'Scaling and expansion planning',
        'Issue resolution and troubleshooting'
      ],
      timeline: 'Ongoing',
      investment: 'Starting at $2,000/month'
    }
  ]

  const customizationOptions = [
    {
      icon: Target,
      title: 'Industry-Specific Solutions',
      description: 'RPA solutions tailored to meet specific industry requirements and compliance standards.'
    },
    {
      icon: Users,
      title: 'Team Size Adaptability',
      description: 'Scalable solutions that grow with your team, from small businesses to enterprise organizations.'
    },
    {
      icon: DollarSign,
      title: 'Flexible Pricing Models',
      description: 'Choose from project-based, subscription, or hybrid pricing models that fit your budget.'
    },
    {
      icon: Clock,
      title: 'Phased Implementation',
      description: 'Gradual rollout options that minimize disruption while maximizing adoption success.'
    }
  ]

  return (
    <>
      {/* Hero Section */}
      <Section background="blue">
        <div className="text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Comprehensive RPA Services
            <span className="text-blue-600"> Tailored to You</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto mb-8">
            From initial assessment to ongoing optimization, our end-to-end RPA services 
            are designed to deliver measurable results while adapting to your unique 
            business environment and objectives.
          </p>
          <Link
            to="/contact"
            className="bg-blue-600 text-white px-8 py-4 rounded-lg text-lg font-medium hover:bg-blue-700 transition-colors inline-flex items-center"
          >
            Discuss Your Project
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </Section>

      {/* Main Services */}
      <Section background="white">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Our Core RPA Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Each service is fully customizable to match your specific needs, 
            timeline, and budget requirements.
          </p>
        </div>
        <div className="space-y-12">
          {mainServices.map((service, index) => (
            <div key={index} className={`grid grid-cols-1 lg:grid-cols-3 gap-8 items-start ${index % 2 === 1 ? 'lg:grid-flow-col-dense' : ''}`}>
              <div className={`lg:col-span-2 ${index % 2 === 1 ? 'lg:order-2' : ''}`}>
                <ServiceCard
                  icon={service.icon}
                  title={service.title}
                  description={service.description}
                  features={service.features}
                  className="h-full"
                />
              </div>
              <div className={`lg:col-span-1 ${index % 2 === 1 ? 'lg:order-1' : ''}`}>
                <div className="bg-gray-50 rounded-lg p-6">
                  <h4 className="font-semibold text-gray-900 mb-4">Service Details</h4>
                  <div className="space-y-3">
                    <div className="flex items-center">
                      <Clock className="h-5 w-5 text-blue-600 mr-2" />
                      <span className="text-sm text-gray-700">Timeline: {service.timeline}</span>
                    </div>
                    <div className="flex items-center">
                      <DollarSign className="h-5 w-5 text-blue-600 mr-2" />
                      <span className="text-sm text-gray-700">{service.investment}</span>
                    </div>
                  </div>
                  <Link
                    to="/contact"
                    className="mt-4 block w-full text-center bg-blue-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-blue-700 transition-colors"
                  >
                    Get Quote
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* Customization Options */}
      <Section background="gray">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Customization is Our Specialty
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We understand that every business is unique. That's why all our services 
            can be adapted to fit your specific requirements, constraints, and goals.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {customizationOptions.map((option, index) => (
            <div key={index} className="bg-white rounded-lg p-6 text-center">
              <div className="bg-blue-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <option.icon className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{option.title}</h3>
              <p className="text-gray-600 text-sm">{option.description}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Process Overview */}
      <Section background="white">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Our Proven Process
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We follow a structured approach that ensures successful RPA implementation 
            while maintaining flexibility to adapt to your unique requirements.
          </p>
        </div>
        <div className="max-w-4xl mx-auto">
          <div className="space-y-8">
            {[
              {
                step: '01',
                title: 'Discovery & Assessment',
                description: 'Deep dive into your current processes, identify pain points, and evaluate automation potential.'
              },
              {
                step: '02',
                title: 'Strategy & Planning',
                description: 'Develop a customized automation roadmap with clear timelines, milestones, and success metrics.'
              },
              {
                step: '03',
                title: 'Design & Development',
                description: 'Create tailored RPA solutions with your specific requirements, integrations, and business rules.'
              },
              {
                step: '04',
                title: 'Testing & Validation',
                description: 'Comprehensive testing in controlled environments to ensure reliability and performance.'
              },
              {
                step: '05',
                title: 'Deployment & Training',
                description: 'Smooth go-live with complete user training and change management support.'
              },
              {
                step: '06',
                title: 'Optimization & Support',
                description: 'Ongoing monitoring, maintenance, and continuous improvement to maximize ROI.'
              }
            ].map((item, index) => (
              <div key={index} className="flex items-start">
                <div className="bg-blue-600 text-white rounded-full w-12 h-12 flex items-center justify-center font-bold text-lg mr-6 flex-shrink-0">
                  {item.step}
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{item.title}</h3>
                  <p className="text-gray-600">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* CTA Section */}
      <Section background="blue">
        <div className="text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Let's discuss your specific needs and create a customized RPA solution 
            that delivers real results for your business.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/contact"
              className="bg-blue-600 text-white px-8 py-4 rounded-lg text-lg font-medium hover:bg-blue-700 transition-colors inline-flex items-center justify-center"
            >
              Schedule Consultation
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
            <Link
              to="/industries"
              className="border-2 border-gray-600 text-gray-700 px-8 py-4 rounded-lg text-lg font-medium hover:bg-gray-600 hover:text-white transition-colors text-center"
            >
              View Industry Solutions
            </Link>
          </div>
        </div>
      </Section>
    </>
  )
}
