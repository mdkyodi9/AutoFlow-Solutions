/**
 * Industries page showcasing industry-specific RPA applications and case studies
 * Demonstrates expertise across various sectors with relevant examples
 */
import { Link } from 'react-router'
import { 
  Building2, 
  Heart, 
  Factory, 
  Banknote, 
  ShoppingCart, 
  GraduationCap,
  ArrowRight,
  CheckCircle
} from 'lucide-react'
import Section from '../components/Section'

export default function Industries() {
  const industries = [
    {
      icon: Banknote,
      name: 'Finance & Banking',
      description: 'Streamline financial operations with compliant automation solutions.',
      image: 'https://pub-cdn.sider.ai/u/U0NWHZXYREX/web-coder/688e74702b2b5e92a4f104a7/resource/7e262359-311a-4ad5-9b2b-c6298bac8428.jpg',
      processes: [
        'Loan processing and approvals',
        'KYC and compliance verification',
        'Account reconciliation',
        'Regulatory reporting',
        'Invoice processing and payments'
      ],
      caseStudy: {
        company: 'Regional Bank',
        challenge: 'Manual loan processing taking 5-7 days',
        solution: 'Automated application review and credit scoring',
        result: 'Reduced processing time to 24 hours, 60% cost reduction'
      },
      roi: '300% ROI in first year'
    },
    {
      icon: Heart,
      name: 'Healthcare',
      description: 'Improve patient care while ensuring HIPAA compliance and data security.',
      image: 'https://pub-cdn.sider.ai/u/U0NWHZXYREX/web-coder/688e74702b2b5e92a4f104a7/resource/d93031dc-9c3f-4a26-a2a4-f1509c72b21c.jpg',
      processes: [
        'Patient registration and scheduling',
        'Insurance verification and claims',
        'Medical records management',
        'Billing and collections',
        'Regulatory compliance reporting'
      ],
      caseStudy: {
        company: 'Healthcare Network',
        challenge: 'Manual insurance verification causing delays',
        solution: 'Automated eligibility checks and pre-authorization',
        result: '85% reduction in claim denials, improved patient satisfaction'
      },
      roi: '250% ROI within 18 months'
    },
    {
      icon: Factory,
      name: 'Manufacturing',
      description: 'Optimize supply chain and production processes for operational excellence.',
      image: 'https://pub-cdn.sider.ai/u/U0NWHZXYREX/web-coder/688e74702b2b5e92a4f104a7/resource/69767ac7-0987-4ea3-a662-907e7f31ab0d.jpg',
      processes: [
        'Inventory management and tracking',
        'Purchase order processing',
        'Quality control reporting',
        'Supply chain coordination',
        'Production scheduling'
      ],
      caseStudy: {
        company: 'Manufacturing Corp',
        challenge: 'Manual inventory tracking causing stockouts',
        solution: 'Real-time inventory automation with predictive ordering',
        result: '40% reduction in stockouts, 25% inventory cost savings'
      },
      roi: '400% ROI in first year'
    },
    {
      icon: ShoppingCart,
      name: 'Retail & E-commerce',
      description: 'Enhance customer experience and streamline operations across channels.',
      image: 'https://pub-cdn.sider.ai/u/U0NWHZXYREX/web-coder/688e74702b2b5e92a4f104a7/resource/ffac25d0-1464-4abf-a3e3-c7e379d34f7b.jpg',
      processes: [
        'Order processing and fulfillment',
        'Inventory synchronization',
        'Customer service automation',
        'Price monitoring and updates',
        'Returns and refunds processing'
      ],
      caseStudy: {
        company: 'E-commerce Platform',
        challenge: 'Manual order processing during peak seasons',
        solution: 'End-to-end order automation with exception handling',
        result: '90% faster processing, 99.5% accuracy rate'
      },
      roi: '350% ROI in 8 months'
    },
    {
      icon: Building2,
      name: 'Insurance',
      description: 'Accelerate claims processing and improve customer satisfaction.',
      image: 'https://pub-cdn.sider.ai/u/U0NWHZXYREX/web-coder/688e74702b2b5e92a4f104a7/resource/5ff12aa3-6051-463d-9492-cd7f88052e12.jpg',
      processes: [
        'Claims processing and adjudication',
        'Policy underwriting',
        'Customer onboarding',
        'Regulatory compliance',
        'Premium calculations'
      ],
      caseStudy: {
        company: 'Insurance Provider',
        challenge: 'Claims processing taking weeks to complete',
        solution: 'Automated claims intake, validation, and routing',
        result: '70% faster claims processing, improved customer retention'
      },
      roi: '280% ROI within 12 months'
    },
    {
      icon: GraduationCap,
      name: 'Education',
      description: 'Streamline administrative processes to focus more on student success.',
      image: 'https://pub-cdn.sider.ai/u/U0NWHZXYREX/web-coder/688e74702b2b5e92a4f104a7/resource/adb1097d-76fc-4680-991c-ee5bf87f958b.jpg',
      processes: [
        'Student enrollment and registration',
        'Grade reporting and transcripts',
        'Financial aid processing',
        'Course scheduling',
        'Compliance reporting'
      ],
      caseStudy: {
        company: 'University System',
        challenge: 'Manual student registration causing bottlenecks',
        solution: 'Automated registration with prerequisite validation',
        result: '60% reduction in registration time, improved student experience'
      },
      roi: '200% ROI in 2 years'
    }
  ]

  return (
    <>
      {/* Hero Section */}
      <Section background="blue">
        <div className="text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Industry-Specific
            <span className="text-blue-600"> RPA Solutions</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto mb-8">
            Every industry has unique challenges and requirements. Our RPA solutions 
            are tailored to address sector-specific needs while ensuring compliance 
            and maximizing operational efficiency.
          </p>
          <Link
            to="/contact"
            className="bg-blue-600 text-white px-8 py-4 rounded-lg text-lg font-medium hover:bg-blue-700 transition-colors inline-flex items-center"
          >
            Discuss Your Industry Needs
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </Section>

      {/* Industries Grid */}
      <Section background="white">
        <div className="space-y-16">
          {industries.map((industry, index) => (
            <div key={index} className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${index % 2 === 1 ? 'lg:grid-flow-col-dense' : ''}`}>
              <div className={index % 2 === 1 ? 'lg:order-2' : ''}>
                <div className="flex items-center mb-4">
                  <div className="bg-blue-100 rounded-lg p-3 mr-4">
                    <industry.icon className="h-8 w-8 text-blue-600" />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900">{industry.name}</h2>
                </div>
                <p className="text-lg text-gray-600 mb-6">{industry.description}</p>
                
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Common Automation Areas:</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-6">
                  {industry.processes.map((process, idx) => (
                    <div key={idx} className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                      <span className="text-gray-700 text-sm">{process}</span>
                    </div>
                  ))}
                </div>

                <div className="bg-blue-50 rounded-lg p-6">
                  <h4 className="font-semibold text-gray-900 mb-2">Success Story</h4>
                  <div className="space-y-2 text-sm text-gray-700">
                    <p><strong>Client:</strong> {industry.caseStudy.company}</p>
                    <p><strong>Challenge:</strong> {industry.caseStudy.challenge}</p>
                    <p><strong>Solution:</strong> {industry.caseStudy.solution}</p>
                    <p><strong>Result:</strong> {industry.caseStudy.result}</p>
                    <p className="text-blue-600 font-semibold">{industry.roi}</p>
                  </div>
                </div>
              </div>
              <div className={index % 2 === 1 ? 'lg:order-1' : ''}>
                <img 
                  src={industry.image}
                  alt={industry.name}
                  className="rounded-lg shadow-lg object-cover w-full h-96"
                />
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* Cross-Industry Benefits */}
      <Section background="gray">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Proven Results Across Industries
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            While each industry has unique needs, our RPA solutions consistently 
            deliver measurable improvements across key performance indicators.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            { metric: '70%', description: 'Average processing time reduction' },
            { metric: '99.9%', description: 'Accuracy rate in automated tasks' },
            { metric: '40%', description: 'Operational cost savings' },
            { metric: '6 months', description: 'Average payback period' }
          ].map((stat, index) => (
            <div key={index} className="bg-white rounded-lg p-6 text-center">
              <div className="text-4xl font-bold text-blue-600 mb-2">{stat.metric}</div>
              <p className="text-gray-700">{stat.description}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Industry Expertise */}
      <Section background="white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            Don't See Your Industry?
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            We've successfully implemented RPA solutions across dozens of industries. 
            Our adaptable approach means we can tailor automation solutions for any 
            business vertical, regardless of complexity or regulatory requirements.
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            {[
              'Real Estate', 'Transportation', 'Energy & Utilities', 'Government',
              'Telecommunications', 'Media & Entertainment', 'Non-Profit', 'Legal Services'
            ].map((industry, index) => (
              <div key={index} className="bg-gray-50 rounded-lg p-3 text-center">
                <span className="text-gray-700 text-sm font-medium">{industry}</span>
              </div>
            ))}
          </div>
          <Link
            to="/contact"
            className="bg-blue-600 text-white px-8 py-4 rounded-lg text-lg font-medium hover:bg-blue-700 transition-colors inline-flex items-center"
          >
            Discuss Your Industry
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </Section>
    </>
  )
}
