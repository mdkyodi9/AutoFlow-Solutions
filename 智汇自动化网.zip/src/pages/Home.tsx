/**
 * Homepage component showcasing RPA expertise and personalized solutions
 * Features hero section, services overview, testimonials, and call-to-action
 */
import { Link } from 'react-router'
import { 
  ArrowRight, 
  Zap, 
  Users, 
  TrendingUp, 
  Shield, 
  Settings, 
  BarChart3,
  CheckCircle
} from 'lucide-react'
import Section from '../components/Section'
import ServiceCard from '../components/ServiceCard'
import TestimonialCard from '../components/TestimonialCard'

export default function Home() {
  const benefits = [
    { icon: Zap, title: 'Faster Processes', description: 'Reduce processing time by up to 80%' },
    { icon: TrendingUp, title: 'Cost Reduction', description: 'Save 30-50% on operational costs' },
    { icon: Shield, title: 'Error Reduction', description: '99.9% accuracy in automated tasks' },
    { icon: Users, title: 'Employee Focus', description: 'Free staff for strategic work' }
  ]

  const features = [
    'Comprehensive process assessment',
    'Custom automation development',
    'Seamless integration support',
    'Ongoing maintenance & optimization'
  ]

  return (
    <>
      {/* Hero Section */}
      <Section background="blue" className="relative overflow-hidden">
        <div className="relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
                Transform Your Business with 
                <span className="text-blue-600"> Personalized RPA</span> Solutions
              </h1>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Unlock efficiency and growth with our tailored Robotic Process Automation 
                solutions. We design, implement, and optimize automation strategies 
                specifically for your unique business needs.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/contact"
                  className="bg-blue-600 text-white px-8 py-4 rounded-lg text-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center"
                >
                  Get Free Consultation
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
                <Link
                  to="/services"
                  className="border-2 border-blue-600 text-blue-600 px-8 py-4 rounded-lg text-lg font-medium hover:bg-blue-600 hover:text-white transition-colors text-center"
                >
                  Explore Services
                </Link>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://pub-cdn.sider.ai/u/U0NWHZXYREX/web-coder/688e74702b2b5e92a4f104a7/resource/c1b4fe17-e2e2-4a9e-904a-f07321a36943.jpg" 
                alt="RPA Automation" 
                className="rounded-lg shadow-2xl object-cover w-full h-96"
              />
            </div>
          </div>
        </div>
      </Section>

      {/* Benefits Section */}
      <Section background="white">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Why Choose Our RPA Solutions?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Experience measurable improvements in efficiency, accuracy, and cost savings 
            with our personalized automation approach.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {benefits.map((benefit, index) => (
            <div key={index} className="text-center">
              <div className="bg-blue-100 rounded-full p-6 w-20 h-20 mx-auto mb-4 flex items-center justify-center">
                <benefit.icon className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{benefit.title}</h3>
              <p className="text-gray-600">{benefit.description}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Services Preview */}
      <Section background="gray">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Our Comprehensive RPA Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            From initial assessment to ongoing optimization, we provide end-to-end 
            RPA solutions tailored to your business requirements.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <ServiceCard
            icon={BarChart3}
            title="Process Assessment"
            description="Comprehensive analysis to identify automation opportunities and ROI potential."
            features={['Current state analysis', 'Automation roadmap', 'ROI calculations']}
          />
          <ServiceCard
            icon={Settings}
            title="Custom Development"
            description="Tailored RPA solutions built specifically for your unique business processes."
            features={['Custom bot development', 'Integration planning', 'Testing & validation']}
          />
          <ServiceCard
            icon={Users}
            title="Implementation Support"
            description="Complete support throughout deployment with training and change management."
            features={['Deployment assistance', 'Staff training', 'Change management']}
          />
        </div>
        <div className="text-center mt-12">
          <Link
            to="/services"
            className="bg-blue-600 text-white px-8 py-3 rounded-lg text-lg font-medium hover:bg-blue-700 transition-colors inline-flex items-center"
          >
            View All Services
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </Section>

      {/* What Sets Us Apart */}
      <Section background="white">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              What Sets Us Apart
            </h2>
            <p className="text-lg text-gray-600 mb-8">
              Unlike one-size-fits-all solutions, we take a personalized approach to RPA 
              implementation, ensuring each solution is perfectly aligned with your 
              business objectives and processes.
            </p>
            <div className="space-y-4">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center">
                  <CheckCircle className="h-6 w-6 text-green-500 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">{feature}</span>
                </div>
              ))}
            </div>
          </div>
          <div>
            <img 
              src="https://pub-cdn.sider.ai/u/U0NWHZXYREX/web-coder/688e74702b2b5e92a4f104a7/resource/1f11cd82-9a40-4452-8fb4-81fa2f076825.jpg" 
              alt="Our Team" 
              className="rounded-lg shadow-lg object-cover w-full h-80"
            />
          </div>
        </div>
      </Section>

      {/* Testimonials */}
      <Section background="gray">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            What Our Clients Say
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Don't just take our word for it. Here's what businesses say about 
            our personalized RPA solutions.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <TestimonialCard
            name="Sarah Johnson"
            company="TechCorp Industries"
            role="Operations Director"
            testimonial="AutoFlow's personalized approach transformed our invoice processing. We've reduced processing time by 75% and eliminated manual errors completely."
            avatar="https://pub-cdn.sider.ai/u/U0NWHZXYREX/web-coder/688e74702b2b5e92a4f104a7/resource/09be6e03-9eb1-43e8-ae0f-3ec1f8cdf1c0.jpg"
          />
          <TestimonialCard
            name="Michael Chen"
            company="FinanceFirst Bank"
            role="VP of Operations"
            testimonial="The team understood our unique compliance requirements and delivered a solution that not only automated our processes but enhanced our audit capabilities."
            avatar="https://pub-cdn.sider.ai/u/U0NWHZXYREX/web-coder/688e74702b2b5e92a4f104a7/resource/a8a76b6d-b343-4a90-9105-4b6c2410efaa.jpg"
          />
          <TestimonialCard
            name="Emily Rodriguez"
            company="HealthCare Plus"
            role="IT Manager"
            testimonial="From assessment to implementation, AutoFlow provided exceptional support. Our patient data processing is now 90% faster and completely accurate."
            avatar="https://pub-cdn.sider.ai/u/U0NWHZXYREX/web-coder/688e74702b2b5e92a4f104a7/resource/c3f8168c-a75a-4617-9ed7-8cd474d390db.jpg"
          />
        </div>
      </Section>

      {/* CTA Section */}
      <Section background="blue">
        <div className="text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Ready to Transform Your Business?
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Schedule a free consultation to discover how our personalized RPA solutions 
            can streamline your operations and drive growth.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/contact"
              className="bg-blue-600 text-white px-8 py-4 rounded-lg text-lg font-medium hover:bg-blue-700 transition-colors inline-flex items-center justify-center"
            >
              Schedule Free Consultation
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
            <Link
              to="/industries"
              className="border-2 border-gray-600 text-gray-700 px-8 py-4 rounded-lg text-lg font-medium hover:bg-gray-600 hover:text-white transition-colors text-center"
            >
              Explore Industry Solutions
            </Link>
          </div>
        </div>
      </Section>
    </>
  )
}
