/**
 * About page presenting company background, team expertise, and unique approach
 * Showcases the human side of the business and builds trust with potential clients
 */
import { Link } from 'react-router'
import { 
  Users, 
  Award, 
  Target, 
  Lightbulb,
  ArrowRight,
  CheckCircle,
  Star
} from 'lucide-react'
import Section from '../components/Section'

export default function About() {
  const team = [
    {
      name: 'David Chen',
      role: 'CEO & Founder',
      expertise: 'RPA Strategy & Business Transformation',
      experience: '15+ years',
      image: 'https://pub-cdn.sider.ai/u/U0NWHZXYREX/web-coder/688e74702b2b5e92a4f104a7/resource/1d4d80fd-031a-495b-a81a-b60726ffde7b.jpg',
      bio: 'Former consulting director with extensive experience in process optimization and digital transformation across Fortune 500 companies.'
    },
    {
      name: 'Sarah Williams',
      role: 'Chief Technology Officer',
      expertise: 'RPA Development & Architecture',
      experience: '12+ years',
      image: 'https://pub-cdn.sider.ai/u/U0NWHZXYREX/web-coder/688e74702b2b5e92a4f104a7/resource/68e51491-ba11-4c62-8769-1723085a5ea2.jpg',
      bio: 'Expert in enterprise automation platforms with a track record of delivering complex RPA solutions for regulated industries.'
    },
    {
      name: 'Michael Rodriguez',
      role: 'Head of Implementation',
      expertise: 'Change Management & Training',
      experience: '10+ years',
      image: 'https://pub-cdn.sider.ai/u/U0NWHZXYREX/web-coder/688e74702b2b5e92a4f104a7/resource/e87fe457-d65e-466c-b934-8e903a3852d6.jpg',
      bio: 'Specializes in user adoption and change management, ensuring successful RPA deployments with minimal business disruption.'
    },
    {
      name: 'Lisa Kumar',
      role: 'Lead Business Analyst',
      expertise: 'Process Analysis & Optimization',
      experience: '8+ years',
      image: 'https://pub-cdn.sider.ai/u/U0NWHZXYREX/web-coder/688e74702b2b5e92a4f104a7/resource/e758600d-8d4f-49ed-a70a-365008ddae0f.jpg',
      bio: 'Expert in identifying automation opportunities and designing efficient processes that maximize ROI and user satisfaction.'
    }
  ]

  const values = [
    {
      icon: Target,
      title: 'Client-Centric Approach',
      description: 'Every solution is designed around your specific business needs, not generic templates.'
    },
    {
      icon: Award,
      title: 'Excellence in Delivery',
      description: 'We maintain the highest standards in development, testing, and implementation.'
    },
    {
      icon: Users,
      title: 'Collaborative Partnership',
      description: 'We work as an extension of your team, ensuring knowledge transfer and long-term success.'
    },
    {
      icon: Lightbulb,
      title: 'Innovation & Adaptability',
      description: 'We stay ahead of technology trends to provide cutting-edge automation solutions.'
    }
  ]

  const achievements = [
    { number: '200+', description: 'Successful RPA implementations' },
    { number: '50+', description: 'Enterprise clients served' },
    { number: '98%', description: 'Client satisfaction rate' },
    { number: '15+', description: 'Years of combined experience' }
  ]

  return (
    <>
      {/* Hero Section */}
      <Section background="blue">
        <div className="text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            About
            <span className="text-blue-600"> AutoFlow Solutions</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto mb-8">
            We're a team of passionate automation experts dedicated to transforming 
            businesses through personalized RPA solutions. Our mission is to make 
            intelligent automation accessible and impactful for organizations of all sizes.
          </p>
        </div>
      </Section>

      {/* Our Story */}
      <Section background="white">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Our Story
            </h2>
            <div className="space-y-4 text-gray-600">
              <p>
                AutoFlow Solutions was founded in 2019 with a simple yet powerful vision: 
                to democratize business process automation by making it accessible, 
                affordable, and tailored to each organization's unique needs.
              </p>
              <p>
                Our founders, having witnessed the struggles of businesses trying to 
                implement one-size-fits-all automation solutions, recognized the need 
                for a more personalized approach. We believe that successful RPA 
                implementation requires deep understanding of your business, not just 
                technical expertise.
              </p>
              <p>
                Today, we're proud to have helped over 200 organizations across various 
                industries achieve operational excellence through intelligent automation, 
                with an average ROI of 300% within the first year.
              </p>
            </div>
          </div>
          <div>
            <img 
              src="https://pub-cdn.sider.ai/u/U0NWHZXYREX/web-coder/688e74702b2b5e92a4f104a7/resource/ed02e6fe-9c03-43e8-afdc-88edefe5203e.jpg" 
              alt="Our office" 
              className="rounded-lg shadow-lg object-cover w-full h-96"
            />
          </div>
        </div>
      </Section>

      {/* Our Values */}
      <Section background="gray">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Our Core Values
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            These principles guide everything we do and shape how we approach 
            every client relationship and project.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {values.map((value, index) => (
            <div key={index} className="bg-white rounded-lg p-6 text-center">
              <div className="bg-blue-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <value.icon className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{value.title}</h3>
              <p className="text-gray-600 text-sm">{value.description}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Team Section */}
      <Section background="white">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Meet Our Expert Team
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our diverse team brings together decades of experience in automation, 
            business transformation, and technology implementation.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {team.map((member, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden">
              <img 
                src={member.image}
                alt={member.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-1">{member.name}</h3>
                <p className="text-blue-600 font-medium mb-2">{member.role}</p>
                <p className="text-sm text-gray-600 mb-3">{member.expertise}</p>
                <p className="text-xs text-gray-500 mb-3">{member.experience} experience</p>
                <p className="text-sm text-gray-700">{member.bio}</p>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* Achievements */}
      <Section background="blue">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Our Track Record
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Numbers that reflect our commitment to delivering exceptional results 
            and building lasting partnerships with our clients.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {achievements.map((achievement, index) => (
            <div key={index} className="text-center">
              <div className="text-5xl font-bold text-blue-600 mb-2">{achievement.number}</div>
              <p className="text-gray-700 font-medium">{achievement.description}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Approach */}
      <Section background="white">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Unique Approach
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              What sets us apart is our commitment to understanding your business 
              before proposing any technical solution.
            </p>
          </div>
          <div className="space-y-8">
            {[
              {
                title: 'Business First, Technology Second',
                description: 'We start with your business objectives and work backwards to determine the right automation approach.',
                features: ['Business impact assessment', 'ROI-focused solutions', 'Strategic alignment']
              },
              {
                title: 'Collaborative Development',
                description: 'Your team is involved throughout the process, ensuring the solution fits your culture and processes.',
                features: ['Regular stakeholder reviews', 'User feedback integration', 'Knowledge transfer']
              },
              {
                title: 'Phased Implementation',
                description: 'We break down complex projects into manageable phases, delivering value at each stage.',
                features: ['Quick wins identification', 'Risk mitigation', 'Continuous improvement']
              },
              {
                title: 'Long-term Partnership',
                description: 'Our relationship doesn\'t end at go-live. We provide ongoing support to ensure sustained success.',
                features: ['24/7 monitoring', 'Performance optimization', 'Scaling guidance']
              }
            ].map((approach, index) => (
              <div key={index} className="bg-gray-50 rounded-lg p-8">
                <h3 className="text-2xl font-semibold text-gray-900 mb-3">{approach.title}</h3>
                <p className="text-gray-600 mb-4">{approach.description}</p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {approach.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-2 flex-shrink-0" />
                      <span className="text-gray-700 text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* CTA Section */}
      <Section background="gray">
        <div className="text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Ready to Work Together?
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Let's discuss how our personalized approach to RPA can help transform 
            your business operations and drive sustainable growth.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/contact"
              className="bg-blue-600 text-white px-8 py-4 rounded-lg text-lg font-medium hover:bg-blue-700 transition-colors inline-flex items-center justify-center"
            >
              Start the Conversation
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
            <Link
              to="/services"
              className="border-2 border-gray-600 text-gray-700 px-8 py-4 rounded-lg text-lg font-medium hover:bg-gray-600 hover:text-white transition-colors text-center"
            >
              Explore Our Services
            </Link>
          </div>
        </div>
      </Section>
    </>
  )
}
